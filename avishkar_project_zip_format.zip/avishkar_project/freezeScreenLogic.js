 // DOM Elements
        const freezeBtn = document.getElementById('freeze-btn');
        const mainInterface = document.getElementById('main-interface');
        const freezeOverlay = document.getElementById('freeze-overlay');
        const timerDisplay = document.getElementById('timer');
        const unlockProgress = document.getElementById('unlock-progress');
        const dots = document.querySelectorAll('.dot');
        const clickCatcher = document.getElementById('click-catcher');

        // State
        let isFrozen = false;
        let spaceCount = 0;
        let tapCount = 0;
        let timeLeft = 300; // 5 minutes in seconds
        let timerInterval;

        // --- FUNCTIONS ---

        // Format time MM:SS
        function formatTime(seconds) {
            const m = Math.floor(seconds / 60);
            const s = seconds % 60;
            return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
        }

        // Start the Freeze
        function startFreeze() {
            isFrozen = true;
            timeLeft = 300;
            spaceCount = 0;
            tapCount = 0;
            updateDots(0);
            
            // Request Fullscreen (Browser requires this to be triggered by user action)
            const elem = document.documentElement;
            if (elem.requestFullscreen) {
                elem.requestFullscreen();
            } else if (elem.webkitRequestFullscreen) { /* Safari */
                elem.webkitRequestFullscreen();
            }

            // UI Changes
            freezeOverlay.classList.remove('hidden');
            document.body.classList.add('frozen-state');
            
            // Start Timer
            timerDisplay.innerText = formatTime(timeLeft);
            timerInterval = setInterval(() => {
                timeLeft--;
                timerDisplay.innerText = formatTime(timeLeft);
                if (timeLeft <= 0) {
                    endFreeze();
                }
            }, 1000);
        }

        // End the Freeze
        function endFreeze() {
            isFrozen = false;
            clearInterval(timerInterval);
            
            // Exit Fullscreen
            if (document.exitFullscreen) {
                document.exitFullscreen();
            } else if (document.webkitExitFullscreen) {
                document.webkitExitFullscreen();
            }

            // UI Changes
            freezeOverlay.classList.add('hidden');
            document.body.classList.remove('frozen-state');
        }

        // Update the visual unlock dots
        function updateDots(count) {
            if (count > 0) {
                unlockProgress.classList.remove('opacity-0');
            } else {
                setTimeout(() => unlockProgress.classList.add('opacity-0'), 500);
            }
            
            dots.forEach((dot, index) => {
                if (index < count) {
                    dot.classList.remove('bg-gray-600');
                    dot.classList.add('bg-green-500');
                    dot.classList.add('shadow-[0_0_10px_rgba(34,197,94,0.8)]');
                } else {
                    dot.classList.add('bg-gray-600');
                    dot.classList.remove('bg-green-500');
                    dot.classList.remove('shadow-[0_0_10px_rgba(34,197,94,0.8)]');
                }
            });
        }

        // Check Unlock Condition
        function checkUnlock(count) {
            updateDots(count);
            if (count >= 5) {
                // Success animation delay
                setTimeout(() => {
                    endFreeze();
                }, 300);
            }
        }

        // Reset counts if user stops typing/tapping for too long
        let resetTimeout;
        function resetUnlockTimer() {
            clearTimeout(resetTimeout);
            resetTimeout = setTimeout(() => {
                spaceCount = 0;
                tapCount = 0;
                updateDots(0);
            }, 2000); // Reset after 2 seconds of inactivity
        }

        // --- EVENT LISTENERS ---

        freezeBtn.addEventListener('click', startFreeze);

        // Keydown Listener (Spacebar)
        window.addEventListener('keydown', (e) => {
            if (!isFrozen) return;

            // Prevent default spacebar scrolling
            if (e.code === 'Space') {
                e.preventDefault();
                spaceCount++;
                checkUnlock(spaceCount);
                resetUnlockTimer();
            }
        });

        // Tap/Click Listener (Mobile/Mouse)
        // Using clickCatcher div ensures we catch clicks anywhere
        clickCatcher.addEventListener('click', (e) => {
            if (!isFrozen) return;
            
            tapCount++;
            checkUnlock(tapCount);
            resetUnlockTimer();
        });
        
        // Security: Prevent F12 or Right Click context menu to make "freezing" feel more real
        document.addEventListener('contextmenu', event => event.preventDefault());
