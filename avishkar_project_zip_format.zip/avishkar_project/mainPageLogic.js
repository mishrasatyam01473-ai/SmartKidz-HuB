document.getElementById('start-btn').addEventListener('click', function() {
    window.location.href = 'game.html';
});

document.getElementById('contact-Btn').addEventListener('click', function() {
    const contactDetials = document.getElementById('contact-detial');
    if (contactDetials.style.display === 'none' || contactDetials.style.display === '') {
        contactDetials.style.display = 'block';
    } else {
        contactDetials.style.display = 'none';
    }

});