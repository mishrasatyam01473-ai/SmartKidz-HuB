// --- Game Data ---
const STATIC_GAMES = {
    shadows: [
        { id: 'lion', type: 'icon', src: 'cat', color: 'text-orange-500', label: 'Lion' },
        { id: 'fish', type: 'icon', src: 'fish', color: 'text-blue-500', label: 'Fish' },
        { id: 'bird', type: 'icon', src: 'bird', color: 'text-red-500', label: 'Bird' }
    ],
    shapes: [
        { id: 'circle', type: 'icon', src: 'circle', color: 'text-purple-500', label: 'Circle' },
        { id: 'square', type: 'icon', src: 'square', color: 'text-pink-500', label: 'Square' },
        { id: 'triangle', type: 'icon', src: 'triangle', color: 'text-emerald-500', label: 'Triangle' }
    ]
};

// --- App Logic ---
class App {
    constructor() {
        this.homeScreen = document.getElementById('home-screen');
        this.loadingScreen = document.getElementById('loading-screen');
        this.gameContainer = document.getElementById('game-container');
        this.dropArea = document.getElementById('drop-area');
        this.dragArea = document.getElementById('drag-area');
        this.scoreDisplay = document.getElementById('score-display');
        this.successModal = document.getElementById('success-modal');

        this.currentGameType = null;
        this.items = [];
        this.matches = 0;
        this.activeDrag = null;
        this.initialPos = { x: 0, y: 0 };
        this.dragOffset = { x: 0, y: 0 };

        this.initLucide();
    }

    initLucide() {
        lucide.createIcons();
    }

    async startGame(type) {
        this.currentGameType = type;

        if (type === 'pokemon') {
            this.homeScreen.classList.add('hidden');
            this.loadingScreen.classList.remove('hidden');
            this.loadingScreen.classList.add('flex');

            try {
                this.items = await this.fetchPokemonData();
            } catch (e) {
                console.error("API Failed", e);
                alert("Oops! Could not catch Pokemon. Playing Animals instead.");
                this.items = [...STATIC_GAMES.shadows];
                this.currentGameType = 'shadows';
            }

            this.loadingScreen.classList.add('hidden');
            this.loadingScreen.classList.remove('flex');
        } else {
            this.items = [...STATIC_GAMES[type]];
            this.items.sort(() => Math.random() - 0.5);
            this.homeScreen.classList.add('hidden');
        }

        this.gameContainer.classList.remove('hidden');
        this.gameContainer.classList.add('flex');

        this.resetGame(false); // false = don't re-fetch if pokemon
    }

    // FREE API INTEGRATION: PokeAPI
    async fetchPokemonData() {
        // Get 3 random IDs from Gen 1 (1-151) for simplicity
        const ids = [];
        while (ids.length < 3) {
            const r = Math.floor(Math.random() * 151) + 1;
            if (!ids.includes(r)) ids.push(r);
        }

        const promises = ids.map(id =>
            fetch(`https://pokeapi.co/api/v2/pokemon/${id}`)
                .then(res => res.json())
        );

        const results = await Promise.all(promises);

        return results.map(p => ({
            id: p.name,
            type: 'image',
            src: p.sprites.front_default, // Sprite URL
            color: '', // Not needed for images
            label: p.name
        }));
    }

    goHome() {
        this.gameContainer.classList.add('hidden');
        this.gameContainer.classList.remove('flex');
        this.homeScreen.classList.remove('hidden');
        this.successModal.classList.add('hidden');
    }

    async resetGame(shouldRefetch = true) {
        this.matches = 0;
        this.successModal.classList.add('hidden');

        // If it's pokemon mode, fetch new ones on reset for endless fun
        if (this.currentGameType === 'pokemon' && shouldRefetch) {
            // Show mini loading state
            this.dropArea.innerHTML = '<div class="animate-spin-slow"><i data-lucide="loader" class="w-8 h-8 text-indigo-400"></i></div>';
            this.dragArea.innerHTML = '';
            this.items = await this.fetchPokemonData();
            this.initLucide();
        } else if (this.currentGameType !== 'pokemon') {
            // Reshuffle static items
            this.items.sort(() => Math.random() - 0.5);
        }

        this.renderLevel();
        this.updateScore();
    }

    renderLevel() {
        this.dropArea.innerHTML = '';
        this.dragArea.innerHTML = '';

        // --- 1. Render Targets (Top) ---
        this.items.forEach(item => {
            const zone = document.createElement('div');
            zone.className = 'drop-zone w-24 h-24 md:w-32 md:h-32 border-4 border-dashed border-slate-300 rounded-2xl flex items-center justify-center bg-slate-100 transition-all duration-300';
            zone.dataset.match = item.id;

            if (item.type === 'icon') {
                // Icon Logic
                const icon = document.createElement('i');
                icon.setAttribute('data-lucide', item.src);
                const isShape = this.currentGameType === 'shapes';
                icon.className = `w-12 h-12 md:w-16 md:h-16 text-slate-300 ${isShape ? 'fill-slate-200' : ''}`;
                zone.appendChild(icon);
            } else {
                // Image/Pokemon Logic (Silhouette)
                const img = document.createElement('img');
                img.src = item.src;
                img.className = 'w-20 h-20 md:w-24 md:h-24 silhouette select-none pointer-events-none';
                zone.appendChild(img);
            }

            this.dropArea.appendChild(zone);
        });

        // --- 2. Render Draggables (Bottom) ---
        // Shuffle draggable items so they don't match order
        const shuffledItems = [...this.items].sort(() => Math.random() - 0.5);

        shuffledItems.forEach(item => {
            const el = document.createElement('div');
            el.className = 'draggable-item w-24 h-24 md:w-32 md:h-32 bg-white rounded-2xl shadow-lg border-b-4 border-slate-200 flex items-center justify-center z-20 touch-none select-none';
            el.id = `drag-${item.id}`;
            el.dataset.match = item.id;

            if (item.type === 'icon') {
                const icon = document.createElement('i');
                icon.setAttribute('data-lucide', item.src);
                const isShape = this.currentGameType === 'shapes';
                icon.className = `w-14 h-14 md:w-20 md:h-20 ${item.color} ${isShape ? 'fill-current' : ''}`;
                el.appendChild(icon);
            } else {
                const img = document.createElement('img');
                img.src = item.src;
                img.className = 'w-20 h-20 md:w-24 md:h-24 select-none pointer-events-none';
                el.appendChild(img);
            }

            this.dragArea.appendChild(el);

            // Attach Pointer Events
            el.addEventListener('pointerdown', (e) => this.handleDragStart(e, el));
        });

        this.initLucide();
    }

    // --- DRAG & DROP PHYSICS ---

    handleDragStart(e, el) {
        e.preventDefault(); // Stop browser drag
        this.activeDrag = el;

        const rect = el.getBoundingClientRect();
        this.initialPos = { x: rect.left, y: rect.top };

        // Calculate grab offset
        this.dragOffset = {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
        };

        // "Lift" the item
        el.style.position = 'fixed';
        el.style.left = `${rect.left}px`;
        el.style.top = `${rect.top}px`;
        el.style.width = `${rect.width}px`;
        el.style.height = `${rect.height}px`;
        el.style.zIndex = '1000';
        el.classList.add('scale-110', 'shadow-2xl');

        // Add listeners to document to track movement outside the element
        const moveHandler = (e) => this.handleDragMove(e);
        const upHandler = (e) => {
            this.handleDragEnd(e);
            document.removeEventListener('pointermove', moveHandler);
            document.removeEventListener('pointerup', upHandler);
        };

        document.addEventListener('pointermove', moveHandler);
        document.addEventListener('pointerup', upHandler);
    }

    handleDragMove(e) {
        if (!this.activeDrag) return;

        const x = e.clientX - this.dragOffset.x;
        const y = e.clientY - this.dragOffset.y;

        this.activeDrag.style.left = `${x}px`;
        this.activeDrag.style.top = `${y}px`;

        this.checkOverlap(true);
    }

    handleDragEnd(e) {
        if (!this.activeDrag) return;

        const matchFound = this.checkOverlap(false);

        if (matchFound) {
            this.handleSuccess(this.activeDrag, matchFound);
        } else {
            this.handleReturn(this.activeDrag);
        }

        this.activeDrag.classList.remove('scale-110', 'shadow-2xl');
        this.activeDrag = null;
    }

    checkOverlap(onlyHighlight) {
        if (!this.activeDrag) return null;

        const dragRect = this.activeDrag.getBoundingClientRect();
        const dragCenter = {
            x: dragRect.left + dragRect.width / 2,
            y: dragRect.top + dragRect.height / 2
        };

        const zones = document.querySelectorAll('.drop-zone');
        let bestMatch = null;

        zones.forEach(zone => {
            zone.classList.remove('highlight');
            if (zone.classList.contains('filled')) return;

            const zoneRect = zone.getBoundingClientRect();

            // Generous hit detection (if center is inside zone)
            if (dragCenter.x >= zoneRect.left &&
                dragCenter.x <= zoneRect.right &&
                dragCenter.y >= zoneRect.top &&
                dragCenter.y <= zoneRect.bottom) {

                if (this.activeDrag.dataset.match === zone.dataset.match) {
                    bestMatch = zone;
                    if (onlyHighlight) zone.classList.add('highlight');
                }
            }
        });

        return bestMatch;
    }

    handleSuccess(dragEl, zoneEl) {
        // Snap logic
        const zoneRect = zoneEl.getBoundingClientRect();
        dragEl.style.left = `${zoneRect.left}px`;
        dragEl.style.top = `${zoneRect.top}px`;
        dragEl.style.cursor = 'default';

        // Replace with clone to kill listeners
        const newEl = dragEl.cloneNode(true);
        dragEl.parentNode.replaceChild(newEl, dragEl);

        // Visual Feedback
        zoneEl.classList.add('filled');
        zoneEl.classList.remove('border-dashed', 'bg-slate-100');
        zoneEl.classList.add('border-solid', 'bg-green-100', 'border-green-400');

        // Trigger success animations
        this.matches++;
        this.updateScore();
        this.createConfetti(zoneRect.left + zoneRect.width / 2, zoneRect.top + zoneRect.height / 2);

        // Level Complete?
        if (this.matches === this.items.length) {
            setTimeout(() => {
                this.successModal.classList.remove('hidden');
                this.fireworks();
            }, 500);
        }
    }

    handleReturn(el) {
        // Snap back logic (Simplified for MVP: just reset to relative flow)
        el.style.left = 'auto';
        el.style.top = 'auto';
        el.style.position = 'relative';
        el.style.zIndex = '20';
    }

    updateScore() {
        this.scoreDisplay.innerHTML = '';
        for (let i = 0; i < this.matches; i++) {
            const star = document.createElement('i');
            star.setAttribute('data-lucide', 'star');
            star.className = 'w-8 h-8 text-yellow-400 fill-current animate-pop';
            this.scoreDisplay.appendChild(star);
        }
        lucide.createIcons();
    }

    createConfetti(x, y) {
        for (let i = 0; i < 12; i++) {
            const conf = document.createElement('div');
            conf.className = 'confetti';
            conf.style.left = `${x}px`;
            conf.style.top = `${y}px`;
            conf.style.backgroundColor = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff'][Math.floor(Math.random() * 5)];
            conf.style.animationDuration = `${Math.random() * 1 + 0.5}s`;

            const angle = Math.random() * Math.PI * 2;
            const velocity = Math.random() * 60 + 20;
            const tx = Math.cos(angle) * velocity;
            const ty = Math.sin(angle) * velocity - 60;

            conf.style.transform = `translate(${tx}px, ${ty}px)`;

            document.body.appendChild(conf);
            setTimeout(() => conf.remove(), 1000);
        }
    }

    fireworks() {
        const interval = setInterval(() => {
            this.createConfetti(Math.random() * window.innerWidth, -20);
        }, 100);
        setTimeout(() => clearInterval(interval), 2500);
    }
}

const app = new App();